# voxwriter
Blender 2.8 addon to export to the MagicaVoxel .vox format

Exports the selected object to a .vox and optionally creates a palette

### Installation
First download the latest release zip

To install, click "Install..." in Blender Preferences > Add-ons and select the zip.
