===
FAQ
===

The texture doesn't load
"""""""""""""""""""""""""
Consider using the Wavefront .obj format for now.
Currently, only textures with the Source: Single Image is supported.

The objects are loading slowly
""""""""""""""""""""""""""""""""

Consider running IPFS locally, or disabling IPFS.

The objects are rotated incorrectly
""""""""""""""""""""""""""""""""

Use Apply Rotation under export options

The objects are scaled incorrectly
""""""""""""""""""""""""""""""""

Use Apply Scale under export options

I used it and it messed with all my rotations and scales
""""""""""""""""""""""""""""""""

Turn off Apply Rotation and Apply Scale under export options

Getting errors about file paths
""""""""""""""""""""""""""""""""

Always use absolute paths, either disable "use relative paths" under user preferences or unclick the relative path checkbox when selecting your file.
