
＼DLありがとうございます！／

◆猫ビーズブレス
https://toraimukoubou.booth.pm/items/3955049

【導入方法】
・制服ベストテクスチャにインポートしてください。

利用規約はこちらをご確認ください。
https://www.traim-kb.com/use

クレジット：とらいむ工房(@traim_kb)


◆公式HP
https://www.traim-kb.com

◆公式Twitter
https://twitter.com/traim_kb

◆素材配布
http://toraimukoubou.booth.pm
