This is the Safe for Work version.

MMD Mysterious Heroine XX (MHXX) (謎のヒロインXX)
©TYPE-MOON


- Fate/Grand Order

Fanmade Model By ShiroSythr

Iwara: https://ecchi.iwara.tv/users/shirosythr
YouTube: https://www.youtube.com/channel/UCgnnB13sK5l8LMyvppbZoTg
Twitter: https://twitter.com/ShiroSythr
Fantia: https://fantia.jp/fanclubs/388081
Patreon: https://www.patreon.com/ShiroSythr
Pixiv Fanbox: https://shirosythr.fanbox.cc/

This model is mostly complete. There may be slight errors, I will fix them asap.

Rules:
-> You are free to do whatever you want(excluding Guro, Ryoma or any political things)
-> Please do not sell the model or take parts from it.

Any credits given will be appreciated! 
Please notify me if you use my model in any videos, I'd love to see your works! 
Tag me on Twitter @ShiroSythr if you post it there.

Changelog:
<<This Version>>
v0.9: Initial Release

Futher plans:
-> Fixing things



