このreadmeはGoogle翻訳されています。

これは通常のバージョンです。

MMD 謎のヒロインXX
©TYPE-MOON

- Fate/Grand Order

ShiroSythrによるファンメイドモデル

Iwara: https://ecchi.iwara.tv/users/shirosythr
YouTube: https://www.youtube.com/channel/UCgnnB13sK5l8LMyvppbZoTg
Twitter: https://twitter.com/ShiroSythr
Fantia: https://fantia.jp/fanclubs/388081
Patreon: https://www.patreon.com/ShiroSythr
Pixiv Fanbox: https://shirosythr.fanbox.cc/

このモデルはほぼ完成しています。 若干の誤差があるかもしれませんが、早急に修正させていただきます。

ルール：
->あなたは好きなことを自由に行うことができます（Guro、Ryoma、または政治的なことを除く）
->モデルを販売したり、部品を取り外したりしないでください。

与えられたクレジットは高く評価されます！
私のモデルをビデオで使用している場合はお知らせください。あなたの作品を見てみたいです！
Twitter @ShiroSythrに投稿する場合は、タグを付けてください。

変更ログ：
<<このバージョン>>
v0.9：初期リリース

今後の計画：
->修正